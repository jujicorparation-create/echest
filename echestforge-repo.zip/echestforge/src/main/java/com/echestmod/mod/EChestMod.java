package com.echestmod.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.Arrays;
import java.util.List;

@Mod(modid = EChestMod.MODID, name = EChestMod.NAME, version = EChestMod.VERSION, clientSideOnly = true)
public class EChestMod {

    public static final String MODID   = "echestmod";
    public static final String NAME    = "EChest Auto Deposit";
    public static final String VERSION = "1.0.0";

    // 5 daqiqa = 6000 client tick
    private static final int INTERVAL   = 6000;
    private static final int MAX_PER_SLOT = 32;

    private static final List<Item> VALUABLES = Arrays.asList(
        Item.getItemFromBlock(Blocks.DIAMOND_BLOCK),
        Item.getItemFromBlock(Blocks.IRON_BLOCK),
        Item.getItemFromBlock(Blocks.EMERALD_BLOCK),
        Item.getItemFromBlock(Blocks.GOLD_BLOCK)
    );

    private int    tickCount        = 0;
    private boolean waitingEchest   = false;
    private int    waitTick         = 0;

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        MinecraftForge.EVENT_BUS.register(this);
    }

    // ─── CLIENT TICK ───────────────────────────────────────────────────────────
    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;

        // Echest ochilishini kutish timeout (3 soniya)
        if (waitingEchest) {
            waitTick++;
            if (waitTick > 60) {
                waitingEchest = false;
                waitTick = 0;
            }
            return;
        }

        tickCount++;
        if (tickCount >= INTERVAL) {
            tickCount = 0;
            if (hasValuables(mc)) {
                mc.player.sendChatMessage("/team echest");
                waitingEchest = true;
                waitTick      = 0;
            }
        }
    }

    // ─── GUI OPEN EVENT ────────────────────────────────────────────────────────
    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public void onGuiOpen(GuiOpenEvent event) {
        if (!waitingEchest) return;
        if (!(event.getGui() instanceof GuiChest)) return;

        GuiChest gui = (GuiChest) event.getGui();
        ContainerChest container = (ContainerChest) gui.inventorySlots;
        IInventory lower = container.getLowerChestInventory();

        // Ender chest ekanini tekshir (27 slot)
        if (lower.getSizeInventory() != 27) return;

        waitingEchest = false;
        waitTick      = 0;

        Minecraft mc = Minecraft.getMinecraft();

        // 2 tick delay — server inventory sync bo'lsin
        new Thread(() -> {
            try { Thread.sleep(100); } catch (InterruptedException ex) { return; }

            for (int inv = 0; inv < 36; inv++) {
                ItemStack stack = mc.player.inventory.getStackInSlot(inv);
                if (stack.isEmpty() || !VALUABLES.contains(stack.getItem())) continue;
                deposit(mc, container, lower, inv, stack);
            }
        }).start();
    }

    // ─── DEPOSIT LOGIC ─────────────────────────────────────────────────────────
    private void deposit(Minecraft mc, ContainerChest container, IInventory lower,
                         int playerSlot, ItemStack original) {
        Item item      = original.getItem();
        int  remaining = original.getCount();

        // 1) Avval shu itemdan bor, to'liq bo'lmagan slotlarni to'ldir
        for (int es = 0; es < 27 && remaining > 0; es++) {
            ItemStack es_stack = lower.getStackInSlot(es);
            if (es_stack.isEmpty() || es_stack.getItem() != item) continue;
            int cur    = es_stack.getCount();
            if (cur >= MAX_PER_SLOT) continue;
            int canAdd = MAX_PER_SLOT - cur;
            int toAdd  = Math.min(canAdd, remaining);
            remaining = doClick(mc, container, lower, es, playerSlot, item, remaining, toAdd);
        }

        // 2) Bo'sh slotlarga sol
        for (int es = 0; es < 27 && remaining > 0; es++) {
            if (!lower.getStackInSlot(es).isEmpty()) continue;
            int toAdd = Math.min(MAX_PER_SLOT, remaining);
            remaining = doClick(mc, container, lower, es, playerSlot, item, remaining, toAdd);
        }
    }

    /**
     * Echest slotiga "toAdd" miqdor item qo'yadi.
     * Returns updated remaining count.
     */
    private int doClick(Minecraft mc, ContainerChest container, IInventory lower,
                        int echestSlot, int playerSlot, Item item,
                        int remaining, int toAdd) {
        // Inventory state ni yangilaymiz
        ItemStack curEchest = lower.getStackInSlot(echestSlot);
        int newEchestCount  = (curEchest.isEmpty() ? 0 : curEchest.getCount()) + toAdd;
        lower.setInventorySlotContents(echestSlot, new ItemStack(item, newEchestCount));

        int leftInPlayer = remaining - toAdd;
        if (leftInPlayer <= 0) {
            mc.player.inventory.setInventorySlotContents(playerSlot, ItemStack.EMPTY);
        } else {
            mc.player.inventory.setInventorySlotContents(playerSlot, new ItemStack(item, leftInPlayer));
        }

        // Packet: PICKUP click echest slotiga
        Slot slot = container.inventorySlots.get(echestSlot);
        mc.playerController.windowClick(
            container.windowId,
            slot.slotNumber,
            0,
            net.minecraft.inventory.ClickType.PICKUP,
            mc.player
        );

        return leftInPlayer;
    }

    // ─── HELPER ────────────────────────────────────────────────────────────────
    private boolean hasValuables(Minecraft mc) {
        for (int i = 0; i < 36; i++) {
            ItemStack s = mc.player.inventory.getStackInSlot(i);
            if (!s.isEmpty() && VALUABLES.contains(s.getItem())) return true;
        }
        return false;
    }
}
